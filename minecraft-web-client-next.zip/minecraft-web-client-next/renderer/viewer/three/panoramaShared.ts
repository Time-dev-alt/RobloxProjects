export const PANORAMA_VERSION = '1.21.4'
