import { BasePlaygroundScene } from '../baseScene'

export default class RotationIssueScene extends BasePlaygroundScene {
  setupWorld () {
    // todo
  }
}
