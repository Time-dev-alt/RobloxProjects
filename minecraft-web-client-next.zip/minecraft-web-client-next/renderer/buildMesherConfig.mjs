export const dynamicMcDataFiles = ['blocks', 'blockCollisionShapes', 'biomes', 'version']
