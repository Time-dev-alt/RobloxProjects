// Auth is done in the connection option callback. In this app the auth implementation is server side.

const Titles = {}

export {
  Titles
}
