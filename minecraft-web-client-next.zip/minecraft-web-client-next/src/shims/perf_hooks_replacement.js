module.exports.performance = globalThis.performance
