export const DARK_COLORS = {
  bg: '#1e1e1e',
  input: '#2d2d2d',
  text: '#ffffff',
  textDim: '#888888',
  client: '#144218',
  server: '#750200',
  modified: '#f57f17',
  border: '#333333',
  hover: '#404040'
}
