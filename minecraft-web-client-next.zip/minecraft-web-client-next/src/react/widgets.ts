import * as ModuleSignsViewer from './ModuleSignsViewer'

export default [ModuleSignsViewer]
