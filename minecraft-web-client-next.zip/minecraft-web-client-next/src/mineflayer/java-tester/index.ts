import { javaServerTester } from './commands'

window.javaServerTester = javaServerTester
customEvents.on('mineflayerBotCreated', () => {
  //
})
